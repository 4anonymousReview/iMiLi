package org.freeplane.core.ui.components;

import java.util.EventObject;

public class ResizeEvent extends EventObject {

	private static final long serialVersionUID = 3131068483469543037L;

	public ResizeEvent(Object source) {
		super(source);
	}
}
